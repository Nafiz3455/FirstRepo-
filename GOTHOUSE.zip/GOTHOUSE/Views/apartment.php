<?php
session_start();
if(!isset($_SESSION["username"]))
{
    header("Location: ./Login.php");
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
   
    <title>GOTHOUSE APPARTMENT</title>

    
</head>
<body style="background-color:antiquewhite ">
<?php
include "../controllers/apartment-action.php";
require "../controllers/includes/header.php";
require "../controllers/includes/sidebar_links.php";
?>
<a style="float: right" class="logout-e" href="Logout.php">LOG OUT</a>

<div>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" onsubmit="return isValid()" name="AForm">
<h2 style="text-align: center; color:aquamarine; background-color:blueviolet">Add New Appartment</h2>
    <fieldset>
        <legend class="bg-primary"> Applicant Details</legend>
        <label for="Aid">Applicant ID</label>
        <input type="number" name="Aid" id="aid" >  <span id="AidjsE" style="color: red;"> * <?php echo $A_idEr  ?></span> <br>
        <label for="Aname">Applicant Name</label>
        <input type="text" name="Aname"id="name">  <span id="AnamejsE" style="color: red;"> * <?php echo $A_nameEr  ?></span> <br>
        <label for="Aemail">Applicant Email</label>
        <input type="email" name="Aemail"id="mail">  <span id="AemailjsE" style="color: red;"> * <?php echo $A_emailEr  ?></span> <br>
        <label for="Aphone">Applicant Cell No.</label>
        <input type="number" name="Aphone"id="number">  <span id="AphonejsE" style="color: red;"> * <?php echo $A_phoneEr ?></span> <br>
    </fieldset>
    <fieldset>
        <legend class="bg-primary"> Apartment Details</legend>
        <label for="A_pname"> Name Of Project</label>
        <input type="text" name="A_pname">  <span id="A_pnamejsE" style="color: red;"> * <?php echo $Ap_nameEr ?></span> <br>
        <label for="A_buliding">Apartment Building No.</label>
        <input type="text" name="A_buliding"id="building no">  <span id="A_bulidingjsE" style="color: red;"> * <?php echo $A_buildEr ?></span> <br>
        <label for="A_area">Apartment Area</label>
        <input type="text" name="A_area">  <span id="A_areajsE" style="color: red;"> * <?php echo $A_areaEr ?></span> <br>
        <label for="A_price">Apartment Price</label>
        <input type="number" name="A_price"id="price">  <span id="A_pricejsE" style="color: red;"> * <?php echo $A_priceEr ?></span> <br>
    </fieldset>
    <input type="submit" class="add" name="submit" value="Add" onclick = "return formvalidation()" > <br> <br>
    <a href="show-appartment.php">Show All Apartments</a> 

    <!-- <a href="update-appartment.php">Update</a> 
    <a href="delete-appartment.php">Delete</a>  -->

</form>
<script>
function formvalidation()
 {
    let element = document.getElementById("aid").value;
    var len = element.length;
    if (len < 5)
    {
        alert("Aid LENGTH IS LESS THEN 5.");
        return false;
    }

    element = document.getElementById("name").value;
    len = element.length;
    if (len < 5)
    {
        alert("Name LENGTH IS LESS THEN 5.");
        return false;
    }
    element = document.getElementById("number").value;
    len = element.length;
    if (len != 11)
    {
        alert("Phone No Not Valid.");
        return false;
    }
    element = document.getElementById("building no").value;
    len = element.length;
    if (len > 6)
    {
        alert("building No Not Valid because less then 6 chereter");
        return false;
    }
    element = document.getElementById("price").value;
    var price = parseInt(element);
    if (price < 1000000-1)
    {
        alert("price should be greter then one million");
        return false;
    }
    


    return true;
    
}
</script>
</div>
<?php require "../controllers/includes/footer.php" ?>
</body>
</html>