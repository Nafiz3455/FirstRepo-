<?php
session_start();
if(!isset($_SESSION["username"]))
{
    header("Location: ./Login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GOT HOUSE USER</title>
    
 
</head>
<body style="background-color:antiquewhite ">


<a style="float: right" class="logout-e" href="Logout.php">LOG OUT</a>
<a href = "Home.php" class="Home-link"><b>Go back</b></a>  <br> <br>
<div>
<form action="../controllers/user-action.php" method="GET" name="Sform" onsubmit="Result(this); return false;">
    <div>
        <legend>View User Details</legend>
        <label for="username">User Name :</label>
        <input type="text" id="username" name="username" >

        <br> <br>
        <input type="submit" class="Search" name="submit" value="Search">  <br> <br>
        
        <div id="result"><b>Person info will be listed here...</b></div>



</form>

</div>

</div>




<?php
include "../controllers/user-action.php";

require "../controllers/includes/footer.php";

?>

</body>
</html>