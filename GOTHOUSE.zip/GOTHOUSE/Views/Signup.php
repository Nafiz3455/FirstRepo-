
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/signup.css">
    


    <title>GOTHOUSE SIGNUP</title>
</head>

<body >
<?php
include "../controllers/Signup_action.php";
?>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>" method="POST" onsubmit="return validateForm()" name="SForm">

<div class="signup">    
    <h1 style="color: Black;">Signup Page</h1><br>  
        <label for="fname"> Full Name  :</label>
        <input type="text" id="fname" name="fname" value="<?php echo $full_name;  ?>">
        <span id="fnamejsE" style="color: red;"> * <?php echo $full_nameEr;  ?></span>
        <br>

        <label for="userName">User Name:</label>
        <input type="text" id="Uname" name="username">
        <span id="usernamejsE" style="color: red;"> * <?php echo $User_NameEr;  ?></span>
        <br>
        <label for="Password">Password   :</label>
        <input type="password" id="Pass" name="password">
        <span id="passwordjsE" style="color: red;"> * <?php echo $User_PasswordEr;  ?></span>
        <br>
        <label for="Roles">Roles   :</label>
        <select  name="roles" id="Roles">
            <option value="">Select one</option>
            <option value="Admin">Admin</option>
            <option value="Buyer">Buyer</option>
            <option value="Seller">Seller</option>
            

        </select><span id="rolejsE" style="color: red;"> * <?php echo $User_RolesEr;  ?></span>
        <br>
        <input type="submit" name="submit" id="log" value="Register" onclick = "return validateForm()"> <br> <br>
  <h4 style="display: inline; color:black"> Already Have an account ?</h4> <a href="./Logins.php">Log In</a><br><br>
  <br><br>
  <a href = "Webview.php" class="Webview-link"><b>Go back</b></a> 
</div>
<script>
function validateForm() {
  let w = document.forms["SForm"]["fname"].value;
  if (w == "") {
    alert("Name must be filled out");
    return false;
  }
  x = document.forms["SForm"]["username"].value;
  if (x == "") {
    alert("User Name must be filled out");
    return false;
  }
  y = document.forms["SForm"]["password"].value;
  if (y == "") {
    alert("Password must be filled out");
    return false;
  }
  z = document.forms["SForm"]["roles"].value;
  if ( z== "") {
    alert("Roles must be filled out");
    return false;
  }
  
}
</script>

</form>

</div>    
<span><?php echo $successMesg ?></span>
<span><?php echo $errorMesg ?></span>
<?php

?>

</body>

</html>
