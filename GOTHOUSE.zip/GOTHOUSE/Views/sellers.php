<?php
session_start();
if(!isset($_SESSION["username"]))
{
    header("Location: ./Login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 
    <title>GOTHOUSE RENTERS</title>
    
</head>
<body style="background-color:antiquewhite ">
<?php 
  include "../controllers/sellers-action.php";


?>
<a style="float: right" class="logout-e" href="Logout.php">LOG OUT</a>
<div>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" onsubmit="return validateForm()" name="RForm">
<h2 style="text-align: center; color:aquamarine; background-color:plum">Seller Application</h2>
    <fieldset>
        <legend> Applicant Details</legend>
        <label for="Aid">Applicant ID</label>
        <input type="number" name="Aid"> <span id="AidjsE" style="color: red;"> * <?php echo $A_idEr  ?></span> <br>
        <label for="Aname">Applicant Name</label>
        <input type="text" name="Aname"> <span id="AnamejsE" style="color: red;"> * <?php echo $A_nameEr  ?></span> <br>
        <label for="Aemail">Applicant Email</label>
        <input type="text" name="Aemail"><span id="AemailjsE" style="color: red;"> * <?php echo $A_emailEr  ?></span> <br>
        <label for="Aphone">Applicant Phone No.</label>
        <input type="text" name="Aphone"><span id="AphonejsE" style="color: red;"> * <?php echo $A_phoneEr  ?></span> <br>
   
  
   
        
        
    </fieldset>
   
    <input type="submit" class="add" name="submit" value="Add" onclick = "return validateForm()" > <br> <br>

    <a href="show-sellers.php">Show All Sellers</a> 
    
    <a href = "Home.php" class="Home-link"><b>Go back</b></a>  

</form>
</div>


<?php require "../controllers/includes/footer.php";?>

<script>
function validateForm() {
  let x = document.forms["RForm"]["Aid"].value;
  if (x == "") {
    alert("Applicant must be filled out");
    return false;
  }
  y = document.forms["RForm"]["Aname"].value;
  if (y == "") {
    alert("Applicant Name must be filled out");
    return false;
  }
  z = document.forms["RForm"]["Aemail"].value;
  if ( z== "") {
    alert("Email must be filled out");
    return false;
  }
  i = document.forms["RForm"]["Aphone"].value;
  if ( i== "") {
    alert("Phone must be filled out");
    return false;
  }
  
}
</script>
       

</body>
</html>