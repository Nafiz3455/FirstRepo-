<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
   
   
    <title>GOTHOUSE LOGIN</title>
</head>
<body >



<?php 
$username="";
$password="";

include "../controllers/Login_action.php";


?>


    <div class="login">    
    <h1 style="color: #08ffd1;">GOT HOUSE</h1><br>    

    <form action="<?php echo htmlspecialchars( $_SERVER['PHP_SELF']) ?>" id="logins" method="POST" onsubmit="return validateForm()" name="LForm"> 
    <label  for="username" id="Uname">User Name :</label>
    <input type="text"  name="username" id="Uname" ><span id="usernamejsE" style="color: red;"> * <?php echo $User_NameEr;  ?></span> <br> <br>  

    <label for="password" id="name">password :</label>
    <input type="password" id="Pass" name="password"><span id="passwordjsE" style="color: red;"> * <?php echo $User_passwordEr;  ?> </span><br> <br>
    
    <label for="Roles" id="role">Roles :</label> <br>
        <select  name="roles" id="Roles">
            <option value="">Select one</option>
            <option value="Admin">Admin</option>
            <option value="Buyer">Buyer</option>
            <option value="Seller">Seller</option>
            

        </select>    <span id="rolesjsE" style="color: red;"> * <?php echo $User_rolesEr;  ?> </span><br> <br>
        
        <input  id="log" type="submit" name="submit" id="login-btn" value="Login" onclick = "return validateForm()"> <br> <br>

        
        <br><br>  
        <a href = "Webview.php" class="Webview-link"><b>Go back</b></a>  
        
         <br><br>

         <br><br>
         
         <h4 style="display: inline; color:black"> If you haven't an account</h4><a href="./Signup.php">Sign Up</a>  
    </form> 
    <script>
function validateForm() {
  let x = document.forms["LForm"]["username"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
  y = document.forms["LForm"]["password"].value;
  if (y == "") {
    alert("Password must be filled out");
    return false;
  }
  z = document.forms["LForm"]["roles"].value;
  if ( z== "") {
    alert("Roles must be filled out");
    return false;
  }
  
}
</script>
       
   
</div>

  

</body>
</html>