
<?php 

include "../DB/dbread.php";

function featchUpdateApartmentInfo($id){
	return uApartmentInfo($id);


}

?>

