
<?php 

require_once '../DB/dbdelete.php';

if (deleteSellers($_GET['id'])) {
    header('Location: ../Views/show-sellers.php');
}

 ?>

?>