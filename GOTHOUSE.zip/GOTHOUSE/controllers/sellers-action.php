<?php 
include "../DB/dbinsert.php";
$A_Name = $A_Email = $A_Phone = $A_Id ="";
$A_nameEr = $A_idEr= $A_emailEr = $A_phoneEr="";
$flag =false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $A_Name = input($_POST["Aname"]);
    $A_Id = input($_POST["Aid"]);
    $A_Email  = input($_POST["Aemail"]);
    $Aphone  = input($_POST["Aphone"]);


if (empty($_POST["Aname"])) {

    $A_nameEr = "Applicant Name is required";
    $flag = true;
}
if (empty($_POST["Aid"])) {

    $A_idEr = "Applicant ID is required";
    $flag = true;
}

if (empty($_POST["Aemail"])) {

    $A_emailEr = "Email is required ";
    $flag = true;
}



if (empty($_POST["Aphone"])) {
    $A_phoneEr = "Number is required";
    $flag = true;
}




if (!$flag) {
   
    addSellers($A_Id,$A_Name,$A_Email,$Aphone);

}



}

function input($v)
{
    $v = htmlspecialchars($v);
    $v = trim($v);
    $v = stripslashes($v);
    return $v;
}




?>