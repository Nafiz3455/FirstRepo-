<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GOTHOUSE FOOTER</title>
    <style>
        h4{
            background-color:lightblue ;
            padding: 15px 0px;
            font-size: 20px;
            color: whitesmoke;
            text-align: center;
            text-transform: uppercase;
    font-family: 'Roboto', sans-serif;
    font-weight: 900;
        }
    </style>
</head>

<body>
    <h4 >Copyright© GOT HOUSE Comapny LTD. All Rights Reserved.</h4>
</body>

</html>