<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css"
    />
    <link
      href="https://api.mapbox.com/mapbox-gl-js/v2.1.1/mapbox-gl.css"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="style.css" />
    <title>Frontend Bootcamp</title>
  </head>
  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
      <div class="container">
        <a href="#" class="navbar-brand">Our Services</a>

        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navmenu"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navmenu">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a href="Home.php" class="nav-link">Home</a>
            </li>
            <li class="nav-item">
              <a href="about.php" class="nav-link">About</a>
            </li>
            <li class="nav-item">
              <a href="apartment.php" class="nav-link">Add Apartment Details</a>
            </li>
            <li class="nav-item">
              <a href="sellers.php" class="nav-link">Seller</a>
            </li>
            <li class="nav-item">
              <a href="user.php" class="nav-link">View User's</a>
            </li>
            <li class="nav-item">
              <a href="profile.php" class="nav-link">Profile</a>
            </li>
            <li class="nav-item">
              <a href="Logout.php" class="nav-link">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div>
      <img src="footerg.jpg" alt="footerg.jpg" width="2400" height="450">
     
  </div>

    

    

    
    
    <section id="admins" class="p-5 bg-primary">
      <div class="container">
        <h2 class="text-center text-white">Our Admins</h2>
        <p class="lead text-center text-white mb-5">
          Our admins all have 5+ years experience  as a businessman 
        </p>
        <div class="row g-4">
          <div class="col-md-6 col-lg-3">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                  src="img/n1.jpg"
                  class="rounded-circle mb-3"
                  alt=""
                />
                <h3 class="card-title mb-3">Nafiz Fahad</h3>
                <p class="card-text">
                  NAFIZ FAHAD is the Founder of  Got House.
                  He is also the CEO of this company.
                </p>
                <a href="#"><i class="bi bi-twitter text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-facebook text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-linkedin text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-instagram text-dark mx-1"></i></a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                  src="img/S1.jpg"
                  class="rounded-circle mb-3"
                  alt=""
                />
                <h3 class="card-title mb-3">Kazi Mahmud SS</h3>
                <p class="card-text">
                  KAZI MAHMUD SHAHRIAR SHOPNIL is co-founder of Got House.
                </p>
                <a href="#"><i class="bi bi-twitter text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-facebook text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-linkedin text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-instagram text-dark mx-1"></i></a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                src="img/m1.jpg"
                  class="rounded-circle mb-3"
                  alt=""
                />
                <h3 class="card-title mb-3">Md. Mostakim A</h3>
                <p class="card-text">
                  MD. MOSTAKIM AHMED is also is co-founder of Got House Company LIMITED.
                  
                </p>
                <a href="#"><i class="bi bi-twitter text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-facebook text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-linkedin text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-instagram text-dark mx-1"></i></a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                src="img/a1.jpg"
                  class="rounded-circle mb-3"
                  alt=""
                />
                <h3 class="card-title mb-3">Anik DAS</h3>
                <p class="card-text">
                  ANIK DAS is also our co-founder.
                  He works in our administrative department.
                  
                </p>
                <a href="#"><i class="bi bi-twitter text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-facebook text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-linkedin text-dark mx-1"></i></a>
                <a href="#"><i class="bi bi-instagram text-dark mx-1"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Contact & Map -->
    <section class="p-5">
      <div class="container">
        <div class="row g-4">
          <div class="col-md">
            <h2 class="text-center mb-4">Contact Info</h2>
            <ul class="list-group list-group-flush lead">
              <li class="list-group-item">
                <span class="fw-bold">Main Location:</span>Kuratoli, Khilkhet, Dhaka 1229
              </li>
              <li class="list-group-item">
                <span class="fw-bold">CEO Phone:</span> +8801786211390
              </li>
              <li class="list-group-item">
                <span class="fw-bold">CO-FOUNDER Phone:</span> +8801879617559
              </li>
              <li class="list-group-item">
                <span class="fw-bold">CEO Email:</span> (555)
                fahadnafiz1@gmail.com
              </li>
              <li class="list-group-item">
                <span class="fw-bold">CO-FOUNDER Email:</span>
                kaji1234@gmail.com
              </li>
            </ul>
          </div>
          <div class="col-md">
            <div>
            <h2 class="text-center mb-4">About</h2>
            <p>
<br> This is a Property management website. In this page people who are looking for best and good looking  apartment to Buy and sell and the people who want poperty for rent then this website is the best choice for them  . <br>
Anyone can search Apartment, Buy apartment, Sell a appartment, and also be Tanter <br>
We provide Provide heavy secure and trusted service  .<br>



Thank you.</p>

            </div>
          </div>
        </div>
      </div>
    </section>

    

    

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
      crossorigin="anonymous"
    ></script>
    <script src="https://api.mapbox.com/mapbox-gl-js/v2.1.1/mapbox-gl.js"></script>

    <script>
      mapboxgl.accessToken =
        'pk.eyJ1IjoiYnRyYXZlcnN5IiwiYSI6ImNrbmh0dXF1NzBtbnMyb3MzcTBpaG10eXcifQ.h5ZyYCglnMdOLAGGiL1Auw'
      var map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/streets-v11',
        center: [-71.060982, 42.35725],
        zoom: 18,
      })
    </script>
  </body>
</html>
