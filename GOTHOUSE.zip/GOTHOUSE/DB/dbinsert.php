<?php

require "dbconnect.php";



   function register($full_name, $username, $password, $User_Roles){
       $conn =connect();
    $sql = $conn->prepare("INSERT INTO user (full_name, username, password, roles) VALUES (?, ?, ?, ?)");
    $sql-> bind_param("ssss",$full_name, $username, $password, $User_Roles);
   
   $sql->execute();
   $sql->close();
    $conn->close();
  
}

function addApartment($Aid,$Aname,$Aemail,$Aphone,$A_buliding,$A_area,$A_price,$A_pname){
    $conn =connect();
 $sql = $conn->prepare("INSERT INTO apartment_details (Aid,Aname,Aemail,Aphone,A_buliding,A_area,A_price,A_pname) VALUES (?,?,?,?,?,?,?,?)");
 $sql-> bind_param("ssssssss",$Aid,$Aname,$Aemail,$Aphone,$A_buliding,$A_area,$A_price,$A_pname);

$sql->execute();
$sql->close();
 $conn->close();

}
function updateApartment($A_Id,$A_Name,$A_Email,$A_Phone,$A_Build,$A_Area,$A_Price,$Ap_Name,$Id){
    $conn =connect();
 $sql = $conn->prepare("UPDATE apartment_details set Aid=?,Aname=?,Aemail=?,Aphone=?,A_buliding=?,A_area=?,A_price=?,A_pname=? where id = ?");
 $sql-> bind_param("ssssssssi",$A_Id,$A_Name,$A_Email,$A_Phone,$A_Build,$A_Area,$A_Price,$Ap_Name,$Id);

$sql->execute();
$sql->close();
 $conn->close();

}


function addSellers($A_Id,$A_Name,$A_Email,$Aphone){
    $conn =connect();
 $sql = $conn->prepare("INSERT INTO sellers_details (A_Id,A_Name,A_Email,Aphone) VALUES (?,?,?,?)");
 $sql-> bind_param("ssss",$A_Id,$A_Name,$A_Email,$Aphone);

$sql->execute();
$sql->close();
 $conn->close();

}
/*function s(){
    $conn=connect();
    $sql =$conn->prepare( "SELECT * FROM chat");
   
    $sql->execute();
    $result=$sql->get_result();
   return $result;
 
}
function addv($message,$user){
    $conn=connect();
    $sql = $conn->prepare('INSERT INTO chat (message,user) VALUES (?,?)');
    $sql->bind_param("ss",$message,$user);


    $sql->execute();
    $sql->close();
    $conn->close();
}*/


?>